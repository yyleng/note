#!/bin/sh

. "${TEST_INIT:-./test-init.sh}"

true
